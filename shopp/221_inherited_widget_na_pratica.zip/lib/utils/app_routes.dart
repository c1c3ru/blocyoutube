class AppRoutes {
  static const productDetail = '/product-detail';
}
